package edu.zju.sc.aoot.model;

import org.junit.*;

import org.junit.Assert;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class DieTest {
    /**
     * creat two tests Die
     */
    private Die defaultDie , nineDie;

    /**
     * initiate
     */
    @Before
    public void setUp(){
        this.nineDie = new Die(9);
        this.defaultDie = new Die();
    }

    @Test(expected = IllegalArgumentException.class)
    public void illegalDie(){
        Die illeagl = new Die(0);
    }

    @Test
    public void numOfSides() {
        Assert.assertEquals(6,this.defaultDie.numOfSides());
    }

    @Test
    public void roll() {
        int number = this.defaultDie.roll();
        Assert.assertTrue(number >= 1 && number <= this.defaultDie.numOfSides());
    }

    @Test
    public void topFace() {
        int number = this.defaultDie.topFace();
        Assert.assertTrue(number >= 1 && number <= this.defaultDie.numOfSides());
    }

    @Test
    public void printResult() {
        this.defaultDie.printResult();
        File file = new File("./result.txt");
        if(file.exists()){
            try {
                FileReader fr = new FileReader(file);
                String s = null;
                BufferedReader bufr = new BufferedReader(fr);
                int i = 0;
                int sum = 0;
                while ((s = bufr.readLine()) != null) {
                    i++;
                    int num = 0;
                    if (i != 1) {
                        int j = s.length();
                        num = (int) (s.charAt(9) - '0') * 10000 + (int) (s.charAt(10) - '0') * 1000 + (int) (s.charAt(11) - '0') * 100 +
                                (s.charAt(12) - '0') * 10 + (int) (s.charAt(13) - '0');
                    }
                    sum += num;
                }
                bufr.close();
                fr.close();
                Assert.assertEquals(100000, sum);
            }catch(Exception e){        //处理异常
                e.printStackTrace();
            }
        }
    }
}

package edu.zju.cst.aoot.week5.exception;

public class CopyOfTestExceptionInFinal {

	public static void main(String[] args) {

		Exception ex = null;
		try {
			throw new RuntimeException("first");
		} catch (Exception e) {
			ex = e;
			throw new RuntimeException(e);
		} finally {
			try {
				close();
			} catch (Exception e) {
				if (ex == null)
					// throw new RuntimeException(e);
					throw e;

			}
		}
	}

	public static void close() {
		// do something
		throw new RuntimeException("second");
	}
}

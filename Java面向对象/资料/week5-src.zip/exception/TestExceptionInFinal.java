package edu.zju.cst.aoot.week5.exception;

public class TestExceptionInFinal {

	public static void main(String[] args) {

		try {
			throw new RuntimeException("first");
		} catch (Exception e) {
			throw new RuntimeException(e);
		} finally {
			close();
		}
	}

	public static void close() {
		// do something
		throw new RuntimeException("second");
	}
}

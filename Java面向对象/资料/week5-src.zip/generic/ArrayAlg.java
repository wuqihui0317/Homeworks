package test;

import java.util.Collection;

public class ArrayAlg {

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }

    /**
     * @param a
     * @return
     * @throw IllegalArgumentException
     */
    public static <T extends Comparable<T>> T max1(T[] a) {
        if (a == null || a.length == 0) {
            throw new IllegalArgumentException();
        }
        
        T max = a[0];
        for(T temp:a){
            if(max.compareTo(temp)<0){
                max = temp;
            }
            return max;
        }

        return null;

    }
}

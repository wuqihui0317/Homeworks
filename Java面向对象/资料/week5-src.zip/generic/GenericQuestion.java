package edu.zju.cst.aoot.week5.generic;

import java.util.ArrayList;
import java.util.List;

public class GenericQuestion {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		ArrayList<Dog> dogs1 = new ArrayList<Animal>();
//
//		ArrayList<Animal> animals1 = new ArrayList<Dog>();
//
		List<Animal> list = new ArrayList<Animal>();
//
		ArrayList<Dog> dogs = new ArrayList<Dog>();
//
//		ArrayList<Animal> animals = dogs;
//
		List<Dog> dogList = dogs;
//
		ArrayList<Object> objects = new ArrayList<Object>();
//
		List<Object> objList = objects;
//
//		ArrayList<Object> objs = new ArrayList<Dog>();


	}

	static class Animal<T> {
		public void eat() {
			System.out.println("animal eating");
		}
	}

	static class Dog<T> extends Animal<T> {
		public void eat() {
			System.out.println("dog eating");
		}
	}

	static class Cat<T> extends Animal<T> {
		public void eat() {
			System.out.println("cat eating");
		}
	}
}

package generic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SuppressWarning {

	private int size;
	private String[] elements;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		List<Object> o1 = new ArrayList<Long>();

	}

	public <T> T[] toArray(T[] a) {
		if (a.length < size) {
			@SuppressWarnings("unchecked")
			T[] result = (T[]) Arrays.copyOf(elements, size, a.getClass());
			return result;
		}

		System.arraycopy(elements, 0, a, 0, size);

		if (a.length > size)
			a[size] = null;
		return a;
	}

	@SuppressWarnings("unchecked")
	public <T> T[] toArray2(T[] a) {
		if (a.length < size) {
			T[] result = (T[]) Arrays.copyOf(elements, size, a.getClass());
			return result;
		}

		System.arraycopy(elements, 0, a, 0, size);

		if (a.length > size)
			a[size] = null;
		return a;
	}
}

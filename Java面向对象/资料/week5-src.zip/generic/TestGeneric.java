package generic;

import java.util.ArrayList;
import java.util.List;

public class TestGeneric {

	// Uses raw type (List) �C fails at runtime
	public static void main(String[] args) {
		List<String> strings = new ArrayList<String>();
		unsafeAdd(strings, new Integer(42));
		// String s = strings.get(0); // Exception from compiler generated cast

		System.out.println(strings instanceof List);
		System.out.println(strings instanceof List<?>);

	}

	// note use of raw types
	private static void unsafeAdd(List list, Object o) {
		list.add(o);
	}

	// // There is a compile time warning:
	// Test.java:10: warning: unchecked call to add(E) in raw type List
	// list.add(o);

	// If we ignore the warning, and run the program, we get a
	// ClassCastException
	// where the compiler inserted the cast
	// If we try the following, it won��t compile (see Item 25)

	// private static void unsafeAdd(List<Object> list, Object o) {
	// list.add(o);
	// }

}

package basic.generic;

import java.util.ArrayList;
import java.util.List;

public class TestGeneric3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new TestGeneric3().go();
	}

	public void go(){
		// animal
		ArrayList<Animal> animals = new ArrayList<Animal>();
		animals.add(new Dog());
		animals.add(new Cat());
		animals.add(new Dog());

		takeAnimals(animals);

		// dog
		ArrayList<Dog> dog = new ArrayList<Dog>();
		dog.add(new Dog());
		dog.add(new Dog());
//		takeAnimals(dog);
	}

	public void takeAnimals(ArrayList<Animal> animals){
		for(Animal a:animals){
			a.eat();
		}
	}

	static class Animal<T> {
		public void eat() {
			System.out.println("animal eating");
		}
	}

	static class Dog<T> extends Animal<T> {
		public void eat() {
			System.out.println("dog eating");
		}
	}

	static class Cat<T> extends Animal<T> {
		public void eat() {
			System.out.println("cat eating");
		}
	}
}

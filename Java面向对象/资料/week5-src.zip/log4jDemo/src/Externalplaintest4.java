package edu.zju.cst.aoot.log4j;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
public class Externalplaintest4 {
   static Logger logger = Logger.getLogger(Externalplaintest4.class);
   static Logger logger1 = Logger.getLogger("logger1");
   static Logger logger2 = Logger.getLogger("logger2");

   public static void main(String args[]) {
	   // load configure
      PropertyConfigurator.configure("conf/basic/plainlog4jconfig.txt");

      logger.debug("Here is some DEBUG");
      logger.info("Here is some INFO");
      logger.warn("Here is some WARN");
      logger.error("Here is some ERROR");
      logger.fatal("Here is some FATAL");
   }
}
package edu.zju.cst.aoot.log4j;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
public class Externalxmltest5 {
   static Logger logger = Logger.getLogger(Externalxmltest5.class);
   public static void main(String args[]) {
	   // load configure
      DOMConfigurator.configure("conf/basic/xmllog4jconfig.xml");
      logger.debug("Here is some DEBUG");
      logger.info("Here is some INFO");
      logger.warn("Here is some WARN");
      logger.error("Here is some ERROR");
      logger.fatal("Here is some FATAL");
   }
}
package edu.zju.cst.aoot.log4j;

import java.io.*;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.HTMLLayout;
import org.apache.log4j.WriterAppender;
public class Htmlandwrite2 {
	// log name
   static Logger logger = Logger.getLogger(Htmlandwrite2.class);
   public static void main(String args[]) {
	   // layout
      HTMLLayout layout = new HTMLLayout();

      // appender
      WriterAppender appender = null;
      try {
         FileOutputStream output = new FileOutputStream("output2.html");
         appender = new WriterAppender(layout,output);
      } catch(Exception e) {}

      logger.addAppender(appender);
      // set level
      logger.setLevel((Level) Level.DEBUG);

      logger.debug("Here is some DEBUG");
      logger.info("Here is some INFO");
      logger.warn("Here is some WARN");
      logger.error("Here is some ERROR");
      logger.fatal("Here is some FATAL");
   }
}

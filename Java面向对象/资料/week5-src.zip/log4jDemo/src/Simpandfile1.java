package edu.zju.cst.aoot.log4j;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
import org.apache.log4j.FileAppender;


public class Simpandfile1 {
	// log name
   static Logger logger = Logger.getLogger(Simpandfile1.class);

   public static void main(String args[]) {
	   // layout
      SimpleLayout layout = new SimpleLayout();

      // appender
      FileAppender appender = null;
      try {
         appender = new FileAppender(layout,"output1.txt",false);
      } catch(Exception e) {}

      logger.addAppender(appender);

      // set level
      logger.setLevel((Level) Level.ERROR);

      logger.debug("Here is some DEBUG");
      logger.info("Here is some INFO");
      logger.warn("Here is some WARN");
      logger.error("Here is some ERROR");
      logger.fatal("Here is some FATAL");
   }
}
